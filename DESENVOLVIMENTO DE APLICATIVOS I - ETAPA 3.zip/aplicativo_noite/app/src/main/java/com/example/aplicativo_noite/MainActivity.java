package com.example.aplicativo_noite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText editTextTextPersonName3;

     private EditText textView7;
    private EditText textView8;
    private EditText TextView9;
    private EditText TextView10;
    private EditText TextView11;
    private EditText TextView12;
    private EditText edtRua;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Composable

    fun HorizontalScrollScreen() {

        Scaffold(

                topBar = { TopAppBar(title = { Text(text = stringResource(R.string.app_name)) }) }

        )
    {

            Column(

                    modifier = Modifier

                            .fillMaxSize()

                            .padding(16.dp)

            ) {

                // Conteúdo acima da rolagem horizontal


                val scrollState = rememberScrollState()


                Row(

                        modifier = Modifier

                                .horizontalScroll(scrollState)

                                .fillMaxWidth()

                ) {

                    // Conteúdo dentro da rolagem horizontal

                    repeat(20) { index ->

                            Box(

                                    modifier = Modifier

                                            .padding(8.dp)

                                            .size(100.dp)

                                            .background(MaterialTheme.colorScheme.primary)

                            ) {

                        Text(

                                text = "Item $index",

                                style = MaterialTheme.typography.body1,

                                modifier = Modifier.padding(8.dp)

                        )

                    }

                    }

                }


                // Conteúdo abaixo da rolagem horizontal

            }

        }

    }


}
